#include<stdio.h>
#include<conio.h>
#include<malloc.h>
#include<string.h>
FILE *fp2;
int isStopWord(FILE *fp, char *str)
{
    char temp[20];
    rewind(fp);
    while(!feof(fp))
    {
                    fscanf(fp,"%s", temp);
                    if(!strcmp(str, temp))
                    {
                                    return 1;
                    }
    }
    return 0;
}
int removestop(char *inputFileName1)
{
    //char inputFileName1[100]; 
     char temp[100], *temp2;
    char inputFileName2[]="d:\\stopwords.txt"; 
    char temeFile[]="d:\\temp.txt";
    FILE *fp1, *fp2, *fp3;
    int count=1, flag=1;
    char outputFileName[50];
    fp1=fopen(inputFileName2, "r");
    if(!fp1)
    {
          printf("Unable to open the file: %s", inputFileName2);
          getch();
          return 0;
    }
    /*while(flag)
    {itoa(count++, temp, 10);
    strcpy(inputFileName1, "d:\\");
    strcat(inputFileName1,temp);
    strcat(inputFileName1,".doc");*/
    fp2=fopen(inputFileName1, "r");
    if(!fp2)
    {
          printf("Unable to open the file: %s", inputFileName1);
          getch();
          fclose(fp1);
          return 0;
    }
    fp3=fopen(temeFile, "w");
    if(!fp3)
    {
          printf("Unable to open the file: %s", temeFile);
          getch();
          fclose(fp1);
          fclose(fp2);
          return 0;
    }
    while(!feof(fp2))
    {
         fscanf(fp2,"%s", temp);
         if(!isStopWord(fp1, temp))
         {
                             fprintf(fp3,"%s ", temp);
         }
    
    printf("g");
    //getch();
    }
    fflush(fp3);
    fclose(fp2);
    fclose(fp3);
    fp2=fopen(inputFileName1, "w");
    if(!fp2)
    {
          printf("Unable to open the file: %s", inputFileName1);
          getch();
          fclose(fp1);
          return 0;
    }
    fp3=fopen(temeFile, "r");
    if(!fp3)
    {
          printf("Unable to open the file: %s", temeFile);
          getch();
          fclose(fp1);
          fclose(fp2);
          return 0;
    }
    while(!feof(fp3))
    {
         fscanf(fp3,"%s", temp);
         fprintf(fp2,"%s\n", temp);
    }
    fclose(fp2);
    fclose(fp3);
    printf("\nThe file %s has been created",outputFileName);
    fclose(fp1);
    printf("\nPress any key to continue");
    getch();
    return 0;
    
}
int parseSinglefile(char *inputFileName)
{
    char  temp[100], *temp2;
    FILE *fp1;
    int count=1, flag=0;
    char outputFileName[50]="d:\\out.txt";
    fp1=fopen(inputFileName, "r");
    if(!fp1)
    {
          printf("Unable to open the file: %s", inputFileName);
          getch();
          return 0;
    }
    while(!feof(fp1))
    {//itoa(count++, temp, 10);
    //strcpy(outputFileName, "d:\\");
    //strcat(outputFileName,temp);
    //strcat(outputFileName,".txt");
   /* fp2=fopen(outputFileName, "w");
    if(!fp2)
    {
          printf("Unable to open the file: %s", inputFileName);
          getch();
          return 0;
    }*/
    while(!feof(fp1))
    {
         fscanf(fp1,"%s", temp);
         if(!strcmp(temp,"<TEXT>"))
         break;
    }
    while(!feof(fp1))
    {
         fscanf(fp1,"%s", temp);
         if(!strcmp(temp,"</TEXT>"))
         break;
         temp2 = strtok (temp," ,.- \"`' ");
         while (temp2 != NULL)
         {
               //printf ("%s\n",temp2);
                 fprintf(fp2,"%s ", temp2);
                 temp2 = strtok (NULL, " ,.- \"`' ");
          }
         //temp2 = strtok (NULL, " ,.-");
         //fprintf(fp2,"%s ", temp2);
    }
    //fclose(fp2);
    
    }
    //fp2=fopen("d:\\abcd.mkm", "w");
    //fprintf(fp2,"Hello");
    fclose(fp1);
    printf("\nThe file %s has been parsed",inputFileName);
    return 0;
    
}

int main()
{
     char tempFileName[200];
     char outputFileName[200]="d:\\outputFileName.dat";
     char inputFileName[200]="d:\\filename.txt";
     char rootDirectory[200];
     char parentDirectory[200];
     FILE *fp1;
     printf("hello");
     fp1=fopen(inputFileName,"r");//getch();
      if(!fp1)
    {
          printf("Unable to open the file: %s", inputFileName);
          getch();
          return 0;
    }
        fp2=fopen(outputFileName,"w");//getch();
      if(!fp2)
    {
          printf("Unable to open the file: %s", outputFileName);
          getch(); 
          return 0;
    }
     fscanf(fp1,"%s",rootDirectory);
     while(!feof(fp1))
     {
                      fscanf(fp1,"%s",tempFileName);
                      strcpy(parentDirectory,rootDirectory);
                      strcat(parentDirectory,tempFileName);
                      parseSinglefile(parentDirectory);
     }
     fclose(fp1);
     fclose(fp2);
    
    printf("\nPress any key to continue");
    getch();
     removestop(outputFileName);
}
                      
